package com.example.stockspring.controller;

import org.springframework.web.servlet.ModelAndView;

public interface StockPriceController {

	ModelAndView getStockPriceList() throws Exception;

}
