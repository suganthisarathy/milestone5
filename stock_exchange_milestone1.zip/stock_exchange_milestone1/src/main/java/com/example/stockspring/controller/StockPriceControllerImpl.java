package com.example.stockspring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.service.StockPriceService;

@Controller
public class StockPriceControllerImpl implements StockPriceController {
	@Autowired
	private StockPriceService stockPriceService;
	@Override
	@RequestMapping(path="/stockPrice")
	public ModelAndView getStockPriceList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("StockPriceList");
		mv.addObject("stockPriceList",stockPriceService.getStockPriceList());
		return mv;
	}
}
