package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import com.example.stockspring.model.Company;
import com.example.stockspring.model.IpoPlanned;

public interface IpoService {

	IpoPlanned insertIpo(IpoPlanned ipo) throws SQLException;

	public IpoPlanned getIpoId(int id) throws SQLException;

	List<IpoPlanned> getIpoList() throws Exception;

	void updateIpo( IpoPlanned ipo);

	void deleteIpo(int ipoId);



	
	

	
		

 
}
