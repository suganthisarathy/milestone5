package com.example.stockspring.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.stockspring.dao.CompanyDao;
import com.example.stockspring.dao.IpoDao;
import com.example.stockspring.dao.StockPriceDao;
import com.example.stockspring.model.Company;
import com.example.stockspring.model.IpoPlanned;


@RestController
public class RestContollerCompany {
@Autowired
CompanyDao companydao;
@Autowired
StockPriceDao stockpricedao;
@Autowired
IpoDao ipodao;
@GetMapping("/companysectorlist/{sectorid}")
List<Company> sectorList(@PathVariable("sectorid") int sectorid)
{
	return companydao.findBySectorId(sectorid);
}
@GetMapping("/listofcompaniesinsector/{sectorid}/{date1}/{date2}")
Double companySectorList(@PathVariable("sectorid") int sectorid,@PathVariable("date1") Date date1,@PathVariable("date2") Date date2)
{
	int companyCode[]= companydao.findSectorList(sectorid);
for(int i=0;i<companyCode.length;i++)
{
	System.out.println(companyCode[i]);
}
	List<Double> stockPriceList=new ArrayList<>();
	for(int i=0;i<companyCode.length;i++)
	{
		
	stockpricedao.findBycompanycode(companyCode[i],date1,date2).forEach(stockPriceList::add);
	}
	double sum=0;
	for(double j:stockPriceList)
	{
		sum=sum+j;
	}
	return sum;
}
@GetMapping("/companystockpricelist/{companycode}/{date1}/{date2}")
List<Double> stockpriceList(@PathVariable("companycode") int companycode,@PathVariable("date1") Date date1,@PathVariable("date2") Date date2)
{
	return stockpricedao.findBycompanycode(companycode,date1,date2);
}
@GetMapping("/companyipolist/{companycode}")
List<IpoPlanned> ipoList(@PathVariable("companycode") int companycode)
{
	return ipodao.findBycompanycode(companycode);
}
@GetMapping("/company/pattern/{name}")
List<Company> findNameWithPattern(@PathVariable("name") String name)
{
	return companydao.findNameWithPattern(name);
}


}
