package com.example.stockspring.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Entity
@Table(name="ipo_planned")
public class IpoPlanned {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="id")
private int id;

//@NotNull(message="please enter stockexchange")
@Column(name="stock_exchange")
private int stockExchange;
//@OneToOne(cascade=CascadeType.ALL)
//@JoinColumn(name="company_code")
//private Company company;

/*public Company getCompany() {
	return company;
}
public void setCompany(Company company) {
	this.company = company;
}*/
@Column(name="company_code")
private int companycode;
public int getCompanycode() {
	return companycode;
}
public void setCompanycode(int companycode) {
	this.companycode = companycode;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public int getStockExchange() {
	return stockExchange;
}
public void setStockExchange(int stockExchange) {
	this.stockExchange = stockExchange;
}
public float getPricePerShare() {
	return pricePerShare;
}
public void setPricePerShare(float pricePerShare) {
	this.pricePerShare = pricePerShare;
}
public int getTotalNumberOfShares() {
	return totalNumberOfShares;
}
public void setTotalNumberOfShares(int totalNumberOfShares) {
	this.totalNumberOfShares = totalNumberOfShares;
}
public String getOpenDateTime() {
	return openDateTime;
}
public void setOpenDateTime(String openDateTime) {
	this.openDateTime = openDateTime;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
@Column(name="price_per_share")
//@NotNull(message="please enter stockexchange")
private float pricePerShare;
@Column(name="total_no_of_shares")
private int totalNumberOfShares;
@Column(name="open_date_time")
private String openDateTime;
@Column(name="remarks")
private String remarks;
}
