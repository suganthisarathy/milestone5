package com.example.stockspring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="stockexchange")
public class StockExchange {
@Id
@Column(name="stockexchange_id")
@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
//@NotEmpty(message="please enter stock exchange name")
//@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="stockexchange_name")
private String stockExchangeName;
//@NotEmpty(message="please enter brief")
//@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="brief")
private String brief;
//@NotEmpty(message="please enter contact address")
//@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="contactaddress")
private String contactAddress;
//@NotEmpty(message="please enter remarks")
	//@Pattern(regexp="[a-z]{4,10}", message="Please enter 4-10 small case character")
@Column(name="remarks")
private String remarks;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public String getBrief() {
	return brief;
}
public void setBrief(String brief) {
	this.brief = brief;
}
public String getContactAddress() {
	return contactAddress;
}
public void setContactAddress(String contactAddress) {
	this.contactAddress = contactAddress;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
@Override
public String toString() {
	return "StockExchangeData [id=" + id + ", stockExchange=" + stockExchangeName + ", brief=" + brief + ", contactAddress="
			+ contactAddress + ", remarks=" + remarks + "]";
}
public String getStockExchangeName() {
	return stockExchangeName;
}
public void setStockExchangeName(String stockExchangeName) {
	this.stockExchangeName = stockExchangeName;
}

}
